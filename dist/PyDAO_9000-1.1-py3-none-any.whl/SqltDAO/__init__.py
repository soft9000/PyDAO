'''
Supporting namespace for generating Soft9000.com PyDAO projects.

Enjoy!

   -- Randall
'''
