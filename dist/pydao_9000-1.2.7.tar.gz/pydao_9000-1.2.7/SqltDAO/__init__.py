'''
Supporting module for generating Soft9000.com PyDAO
projects. See https://github.com/soft9000/PyDAO for
the |latest| edition.

To start the GUI:

(1) Change directory to your project location
(2) start Python
(3) then:

>>> from SqltDAO import MainGUI

Enjoy!

   -- Randall
'''
